#include <unistd.h>
#include <stdio.h>

int main(void) {
    printf("PID : %d\n", (int)getpid());
    printf("PGRP : %d\n", (int)getpgrp());
    printf("PGID(0) : %d\n", (int)getpgid(0));
    return 0;
}
