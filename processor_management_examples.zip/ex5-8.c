#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <stdio.h>

int main(void) {
    char *val = getenv("SHELL");

    if (val == NULL)
        printf("SHELL not defined\n");
    else
        printf("1. SHELL = %s\n", val);

    if (putenv("SHELL=/usr/bin/csh") != 0) {
        perror("putenv");
        return 1;
    }

    val = getenv("SHELL");
    printf("2. SHELL = %s\n", val);
    return 0;
}
