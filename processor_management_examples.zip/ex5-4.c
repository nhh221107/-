#include <sys/times.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int i;
    struct tms mytms;
    clock_t t1, t2;
    long ticks = sysconf(_SC_CLK_TCK);

    if ((t1 = times(&mytms)) == (clock_t)-1) {
        perror("times 1");
        return 1;
    }

    for (i = 0; i < 999999; i++)
        ;

    if ((t2 = times(&mytms)) == (clock_t)-1) {
        perror("times 2");
        return 1;
    }

    printf("Real time : %.1f sec\n", (double)(t2 - t1) / ticks);
    printf("User time : %.1f sec\n", (double)mytms.tms_utime / ticks);
    printf("System time : %.1f sec\n", (double)mytms.tms_stime / ticks);
    return 0;
}
